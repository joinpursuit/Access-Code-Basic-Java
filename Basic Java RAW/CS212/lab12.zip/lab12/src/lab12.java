import javax.swing.*;
import java.awt.*;
public class lab12{
   
   static TextFileInput inFile;
   static String inFileName = "numbers.txt";
   static JFrame myFrame;
   static Container cPane;
   static TextArea even, odd;
   
   public static void main(String[] args) {
      initialize();
      readNumbersFromFile(inFileName);
      
   }   
   public static void initialize() {
      inFile = new TextFileInput(inFileName);
      even = new TextArea();
      odd = new TextArea();
      myFrame=new JFrame();
      //myFrame.setSize(500,500);
      myFrame.setLocation(200, 200);
      myFrame.setTitle("");
      myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      myFrame.getContentPane().setLayout(new BorderLayout());
      myFrame.getContentPane().add(even, BorderLayout.WEST);
      myFrame.getContentPane().add(odd, BorderLayout.EAST);
      myFrame.pack();
      myFrame.setVisible(true);
      
   }
   public static void readNumbersFromFile(String fileName){
      /*
       * Add code to this method so...
       * - the two text areas are added to the content pane of the JFrame
       *   (see the code in the PowerPoint on GUIs)
       * - numbers are read from the file, and even numbers are put in 
       *   the TextArea "even", odd numbers in "odd".
       * - At end of file, the JFrame is made visible.
       */
	  even.append("even");
	  odd.append("Odd");
      String line;
      line = inFile.readLine();
      while (line != null) 
      {
       
       int n = Integer.parseInt(line);
       if(n%2==0)
       {
    	   even.append("\n" + line);
       }
       else
       {
    	   odd.append("\n" +line);
       }
       line=inFile.readLine();
      }
      
    	   
       
          
          
          
          
      // } //while
   } //readSSNsFromFile
   
      
   
   
   
} //SSN

