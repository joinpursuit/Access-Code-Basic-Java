public class Money implements Comparable<Money> {
	/**
	 * Instance variable for holding dollars as an integer value
	 */
	private int dollars;
	/**
	 * Instance variable for holding cents as an integer value 
	 */
	private int cents;

	/**
	 * No argument constructor for Money that will set dollars and cents to 0
	 */
	public Money() {
		this.dollars = 0;
		this.cents = 0;
	}

	/**
	 * Two argument constructor for Money
	 * @param dollars the integer value of dollars
	 * @param cents the integer value of cents
	 */
	public Money(int dollars, int cents) {
		this.dollars = dollars;
		this.cents = cents;
	}

	@Override
	public String toString() {
		String centString;
		// Test if cents is less than 10 
		if (this.cents < 10) {
			centString = "0" + this.cents; // prepend a 0 if so
		} else {
			centString = String.valueOf(this.cents); // otherwise use regular string representation
		}
		return "$ " + this.dollars + "." + centString;
	}

	@Override
	public int compareTo(Money other) {
		// Compare most significant values first then continue to values of 
		// lesser significance
		if (this.dollars < other.dollars) {
			return -1;
		} else if (this.dollars > other.dollars) {
			return 1;
		} else if (this.cents < other.cents) {
			return -1;
		} else if (this.cents > other.cents) {
			return 1;
		} else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		// test reflexive property
		if(obj==this) {
			return true;
		}
		// first test if null and then if it's an instance of Money
		if (obj != null && obj instanceof Money)
			// check if their money values are equal
			return this.compareTo((Money) obj) == 0;
		return false;
	}

	/**
	 * Get method for cents
	 * @return the cents value
	 */
	public int getCents() {
		return cents;
	}

	/**
	 * Get method for dollars
	 * @return the dollars value
	 */
	public int getDollars() {
		return dollars;
	}

	/**
	 * Main method that instantiates two Money objects and runs 
	 * various methods.
	 * @param args is unused
	 */
	public static void main(String[] args) {
		Money m1 = new Money();
		Money m2 = new Money(6, 5);
		System.out.println(m1.getCents());
		System.out.println(m2.getDollars());
		System.out.println(m2);
		System.out.println(m1.compareTo(m2));
		System.out.println(m1.equals(m2));
	}
}
