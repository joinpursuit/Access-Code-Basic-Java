
public class Money {

		private int dollars, cents, temp;

		public Money()
		{
		this(0,0);	
		}
		
		public Money(int dollars, int cents)
		{
		this.dollars = dollars + cents/100;
		this.cents = cents%100;
		}
		
		public int getCents() 
		{
			return cents;
		}
		
		public int getDollars() 
		{
			return dollars;
		}

		public String toString()
		{
		String centstr;
		if(cents<10)
		{
			centstr="0";
		}
		else
		{
			centstr="";
		}
		
		return "$ " + dollars + "." + centstr + cents;
		}
		
		public boolean equals(Object obj)
		{
			if(obj==null){
				return false;
			}
			
			if(this==obj){
				return true;
			}
			
			if(obj instanceof Money){
				Money temp = (Money)obj;
				return (this.dollars==temp.dollars&& this.cents==temp.cents);
			}
			
			else
				 return false;
		}
		
		public void add(Money o)
		{
			int currInstanceTotalCents = dollars*100 + cents;
			int otherInstanceTotalCents = o.dollars*100 + o.cents;
			int total = currInstanceTotalCents + otherInstanceTotalCents;
			dollars = total/100;
			cents = total%100;
		}
		
		public int compareTo(Money o)
		{
			if(dollars<o.dollars){
				return -1;
			}
			
			else if(dollars>o.dollars){
				return 1;
			}
			
			else if(cents<o.cents){
				return -1;
			}
			
			else if(cents>o.cents){
				return 1;
			}
			
			else {
				return 0;
			//return (dollars*100+cents)-(o.dollars*100+o.cents);
			}
		}

		public static void main(String[] args) 
		{
			Money m1, m2;
			m1 = new Money(4,87);
			m2 = new Money(5,243);
			m1.add(m2);
			System.out.println(m1.toString());
		}
}



