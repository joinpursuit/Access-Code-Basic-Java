
public class Person {

		private String name, birthdate, sex, height;
		private int age;
		private static int population = 0;
		
		public Person(String name, String birthdate, String sex, String height, int age)
		{
			this.name = name;
			this.birthdate = birthdate;
			this.sex = sex;
			this.height = height;
			this.age = age;
			population++;	
		}
		
		public String toString()
		{
			return "My name is " + name + ". I am " + age + " years old.";
		}
		
		public static int getPopulation()
		{
			return population;
		}
		
		public boolean equals(Object obj)
		{
			if(obj==null)
			{
				return false;
			}
			
			if(this == obj)
			{
				return true;	
			}
			
			if(obj instanceof Person)
			{
				Person temp = (Person)obj;
				return (this.name.equals(temp.name)&&this.birthdate.equals(temp.birthdate)&&this.height.equals(temp.height)&&this.sex.equals(temp.sex)&&this.age==temp.age);
			}
			
			return false;
		}
		
		
		public static void main(String[] args) 
		{
		Person blah = new Person("John", "1-1,2000", "male", "5'8\"", 20);
		Person blah2 = new Person("Jane", "1-1,2000", "female", "5'8\"", 20);
		System.out.println(blah.toString());
		System.out.println(blah2);
		System.out.println(getPopulation());
		System.out.println(Integer.parseInt("500"));
		System.out.println((blah.equals(blah2)));
		}

	
}



