
public class Money {

		private int dollars, cents, temp;

		public Money()
		{
		this(0,0);	
		}
		
		public Money(int dollars, int cents)
		{
		this.dollars = dollars;
		this.cents = cents;
		}
		
		public int getCents() 
		{
			return cents;
		}
		
		public int getDollars() 
		{
			return dollars;
		}

		public String toString()
		{
		String centstr;
		if(cents<10)
		{
			centstr="0";
		}
		else
		{
			centstr="";
		}
		
		return "$ " + dollars + "." + centstr + cents;
		}
		
		public boolean equals(Object obj)
		{
			if(obj==null){
				return false;
			}
			
			if(this==obj){
				return true;
			}
			
			if(obj instanceof Money){
				Money temp = (Money)obj;
				return (this.dollars==temp.dollars&& this.cents==temp.cents);
			}
			
			else
				 return false;
		}
		
		public int compareTo(Money o)
		{
			if(dollars<o.dollars){
				return -1;
			}
			
			else if(dollars>o.dollars){
				return 1;
			}
			
			else if(cents<o.cents){
				return -1;
			}
			
			else if(cents>o.cents){
				return 1;
			}
			
			else {
				return 0;
			//return (dollars*100+cents)-(o.dollars*100+o.cents);
			}
		}

		public static void main(String[] args) 
		{
			Money m1 = new Money();
			Money m2 = new Money(6,5);
			System.out.println(m1.getCents());
			System.out.println(m2.getDollars());
			System.out.println(m2);
			System.out.println(m1.compareTo(m2));
			System.out.println(m1.equals(m2));
		}
}



