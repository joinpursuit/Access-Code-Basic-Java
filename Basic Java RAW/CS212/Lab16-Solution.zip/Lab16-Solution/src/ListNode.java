// ListNode.java

public class ListNode
{
   public String data;
   public ListNode next;

   public ListNode(String d)
   {
      data = d;
      next = null;
   }  // constructor
}  // class ShortNode

