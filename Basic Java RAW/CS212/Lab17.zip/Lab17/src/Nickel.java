
public class Nickel {

}
