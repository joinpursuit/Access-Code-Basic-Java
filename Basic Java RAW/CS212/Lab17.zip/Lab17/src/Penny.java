
public class Penny extends Coin {

}
