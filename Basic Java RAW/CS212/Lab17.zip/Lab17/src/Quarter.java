
public class Quarter extends Coin {

      public Quarter () {
         super (25);
      }
      
      public String toString() {
    	  return "I am a quarter";
      }
//      
//      public static void main(String[] args) {
//		Quarter blah = new Quarter();
//		Object temp = (Object) blah;
//		printCoin((Quarter)temp);
//      }
//      
//      public static void printCoin(Coin blah){
//    	  System.out.println(blah);
//      }
}
