import java.util.StringTokenizer;
import javax.swing.*;

public class Gameboard {
	
	private static final int Maximum_Board_Size = 15;
	
	/**
	 * A gameboard constructor that test if there the board size, and c if there are repeated size ships
	 * @param filename
	 */
	public Gameboard(String filename)
	{
		//reads in the first line from the file and set the first token to board size, 2nd token to small ship and 3rd token to big ship size.
		TextFileInput tfi = new TextFileInput(filename);
		String line = tfi.readLine();
		StringTokenizer st;
		st= new StringTokenizer(line, ",");
		int size, small, big;
		size = Integer.parseInt(st.nextToken());
		small = Integer.parseInt(st.nextToken());
		big = Integer.parseInt(st.nextToken());
		
		//if the baord size is less then 1 and the board size, small ship size, big hip size is greater then 15 then throws exception.
		if(size<1||size>Maximum_Board_Size||small>Maximum_Board_Size||big>Maximum_Board_Size)
			throw new IllegalArgumentException("invalid board size.");
		int count2=0,count3=0, count4=0, count5=0;
		
		//check to see if there are repeated size ships, if yes throws argument exception.
		line=tfi.readLine();
		while(line!=null)
		{
			st=new StringTokenizer(line, ",|");
			if(st.countTokens()/2==small)
			{
				count2++;
			}
			if(st.countTokens()/2==small+1)
			{
				count3++;			
			}
			if(st.countTokens()/2==small+2)
			{
				count4++;
			}
			if(st.countTokens()/2==small+3)
			{
				count5++;
			}
				line=tfi.readLine();
		}

		if(count2>1||count3>1||count4>1||count5>1)
			throw new IllegalArgumentException("invalid ship size.");
	}
	
	/**
	 * it tokenizes the coordinates enter by the player see if it hits the board on the opposite player
	 * @param name
	 * @param player
	 */
	public void game(String name, int [][]player)
	{

		int row, col;
		
		//sets up an infinite loop, when player hit the ship of the opposing player. the player continues to enter coordinates until he miss
		while(true)
		{
			String input =JOptionPane.showInputDialog("Enter a cordinates in 0,0 format: ");
			StringTokenizer st= new StringTokenizer(input, ",");
		
			if(st.countTokens()==1)
			{
				if(Integer.parseInt(st.nextToken())==-1)
				System.exit(1);
			}
			row=Integer.parseInt(st.nextToken());
			col=Integer.parseInt(st.nextToken());
			
			//checks if the player's coordinates are valid in the array size.
			if((row>-1&&col>-1) && (row<8&&col<8))
				{
				
					//if player miss, it change the position in the player's array into -2 and display the message you missed.
					if(player[row][col]==0)
					{
						player[row][col]=-2;
						JOptionPane.showMessageDialog(null, "You missed!");
						BattleShipGui.setBoard(name, player);
						break;
					}	
					
					//if player hits, it change the position in the player's array into -1 and display the message you hit.
					else if(player[row][col]>0)
					{
						player[row][col]=-1;
						JOptionPane.showMessageDialog(null, "You hit him");
						BattleShipGui.setBoard(name, player);
						if(allSunk(player))
							break;
					}
					//if player enter the coordinates that was previously enter, it tells the player to reenter
					else
						JOptionPane.showMessageDialog(null, "Please type again");
				}
				// if the format of the coordinates player enter is wrong. it askes them to reenter.	
				else
				JOptionPane.showMessageDialog(null, "Please type again,Wrong formet!!");
		}
	}
			
	
	/**
	 * it reads the files from the player and sets it up in the array
	 * @param filename
	 * @param player
	 */
	public void readFile(String filename,int [][]player)
    {  
        TextFileInput tfi = new TextFileInput(filename);
        String line=tfi.readLine();
        line=tfi.readLine();
        StringTokenizer st;
        int row, col;
        
        //reads all the line into the file
        while(line!=null)
        {
           
        	//Tokenizes every line after it reads in
            st= new StringTokenizer(line, ",|");
            int count=st.countTokens()/2;
            while(st.hasMoreTokens())
            {
            	//sets the first token as the row value and second token as the column value.
                row=Integer.parseInt(st.nextToken());
                col=Integer.parseInt(st.nextToken());
                player[row][col]=count;
            }
            line=tfi.readLine();
        }
    }    
	 
	/**
	 * checks if the player's ship has all been sunk by going through all the arrays
	 * @param player
	 * @return true if all the values in the player array is less or equal to 0
	 */
	public static boolean allSunk(int [][] player)
	   {
		   
		   //checks thru the entire player array if there are value greater then 0 then there are still ships on the baord.
		   for(int r = 0; r < player.length; r++)
		   {
			   for(int c = 0; c < player[r].length; c++)
			   {
				   if(player[r][c]>0)
					   return false;
			   }
		   }
		   return true;
	   }
  
	/**
	 * it checks if any ship has been sunk by going through the entire board to see if there are still an specific size number.
	 * @param player
	 * @return the ships that has been sunk with a String
	 */
	 public static String checkSunk(int[][] player)
	   {
		 	String sunk="";
		 	int count2=0, count3=0, count4=0, count5=0;
		   
		   //for loop that runs through the entire 2d array
		 	for(int r = 0; r < player.length; r++)
		 	{
		 		for(int c = 0; c < player[r].length; c++)
		 		{
				   //if there is value of 2 in anywhere of the array that means that the size 2 ship has not been sunk
		 			if(player[r][c]==2)
					   count2++;
				   
				   //if there is value of 3 in anywhere of the array that means that the size 3 ship has not been sunk
		 			if(player[r][c]==3)
					   count3++;
					   
		 			//if there is value of 4 in anywhere of the array that means that the size 4 ship has not been sunk
		 			if(player[r][c]==4)
						   count4++;
		 			
		 			//if there is value of 5 in anywhere of the array that means that the size 5 ship has not been sunk
		 			if(player[r][c]==5)
						   count5++;
				}
			}
			   
			   //prints out the statement if any of the ships has been sunk.
			   if(count2==0)
				   sunk+="Ship 2 has been sunk\n";
			   if(count3==0)
				   sunk+="Ship 3 has been sunk\n";
			   if(count4==0)
				   sunk+="Ship 4 has been sunk\n";
			   if(count5==0)
				   sunk+="Ship 5 has been sunk\n";
			   return sunk;
		   }
	 
	 /**
	  * change the board of the player array into strings with +,H and X
	  * @param player
	  * @return the board of a player as a mark of +,H,X
	  */
	 public static String print(int[][] player)
	 {
		 String num="";
		 
		 //goes through the entire 2d player array
		 for(int r=0;r<player.length;r++)
		 {
			 for(int c=0;c<player[r].length;c++)
			 {
				 
				 //when the array position number is -1 it changes to String H
				 if(player[r][c]==-1)
					 num+="H";
				 
				 //when the array position number is -2 it changes to String X
				 else if(player[r][c]==-2) 
					 num+="X";
				 
				 //When the array position number is 0. changes to +
				 else
					 num+="+";
			 }
			 num+="\n";
		 }
		 return num +checkSunk(player);
	}
}