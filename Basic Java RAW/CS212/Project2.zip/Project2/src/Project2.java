import javax.swing.*;

public class Project2 {

	/** Haiqiang Zou , Xu Xiang, Mei Ling Lin
	 * @param args
	 */
	public static void main(String[] args) 
	{
		
		// TODO Auto-generated method stub
		
		//initials 2 2d arrays to store the player's board
		int [][] player1=new int [8][8];
		int [][] player2=new int [8][8];
		
		//if the argument length is not 2 throws argument exception
		if(args.length!=2)
			throw new IllegalArgumentException("invalid argument length!");
		
		String name = JOptionPane.showInputDialog("Enter the name for player 1");
		String name2 = JOptionPane.showInputDialog("Enter the name for player 2");
		
		//reads in the file name from arguments
		String file1 = args[0];
		String file2 = args[1];
		
		//read files into the gameboard constructor
		Gameboard a= new Gameboard(file1);
		Gameboard b= new Gameboard(file2);
		
		a.readFile(file1, player1);
		b.readFile(file2,player2);
		
		//sets up a JFrame
		BattleShipGui board = new BattleShipGui();
		
		
		//sets up an infinite loop to alternate the players around.
		while(true)
		{
			//sets up the player's board and the label
			BattleShipGui.setBoard(name , player2);
			BattleShipGui.setLabel(name);
			a.game(name, player2);
	
			//check if the ships has been sunk then it will display the player has win the game
			if(Gameboard.allSunk(player2))
				{
				JOptionPane.showMessageDialog(null, "Congraduation " + name + " has won the game!");
				break; 
				}
			JOptionPane.showMessageDialog(null, name2 + "'s turn");
			
			//sets the up the board for the 2nd player
			BattleShipGui.setBoard(name2 ,player1);
			BattleShipGui.setLabel(name2);
			b.game(name2,player1);
			
			//displays the message player 2 has won the game if player 1 ships has all been sunk
			if(Gameboard.allSunk(player1))
				{
				JOptionPane.showMessageDialog(null, "Congraduation " + name2 + " has won the game!");
				break;
				}
			JOptionPane.showMessageDialog(null, name + "'s turn");
		}
	}
	

}
