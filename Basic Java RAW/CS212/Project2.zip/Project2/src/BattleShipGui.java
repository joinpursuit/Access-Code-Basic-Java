import java.awt.*;
import javax.swing.*;

public class BattleShipGui {
	
		private static JFrame frame;
		private static JLabel label;
		private static JTextArea textArea;
		
		/**
		 * a Constructor that sets up the JFrame
		 */
		public BattleShipGui()
		{
			frame = new JFrame("BattleShipGui");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize( 400,600);//width, height);
	        frame.setLocation(200,50);//x, y);
	        frame.setLayout(new GridLayout(2,1));
	        textArea = new JTextArea(10, 20);
	        textArea.setEditable(false);
	        JScrollPane scrollPane = new JScrollPane(textArea);
	        frame.getContentPane().add(scrollPane);
	    	label = new JLabel();
	    	frame.getContentPane().add(label);
	        //Display the window.
	        frame.setVisible(true);
		}
		
		/**
		 * sets up the board by calling in a method from the Gameboard class.
		 * @param print
		 * @param player
		 */
		public static void setBoard(String print, int[][]player)
		{
			textArea.setText(Gameboard.print(player));
		}
		
		/**
		 * sets up the label to determine the player's turn;
		 * @param name
		 * @return
		 */
		public static JLabel setLabel(String name)
		{
		
			label.setText("The current player is: " + name);
			return label;
		}
			
		
}
