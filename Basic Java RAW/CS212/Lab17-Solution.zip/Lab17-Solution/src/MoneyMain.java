public class MoneyMain {

	static String[] dataSource = { "B5", "Q", "B20", "Q", "P", "N", "D" };
	static Money[] wallet = new Money[dataSource.length];

	public static void main(String[] args) {
		// for each item in dataSource
		for (int i = 0; i < dataSource.length; i++) {
			// get the first character
			char dataItem = dataSource[i].charAt(0);
			// if it's a bill
			if (dataItem == 'B') {
				// Parse the number portion into a value
				int billValue = Integer.parseInt(dataSource[i].substring(1,
						dataSource[i].length()));
				// create the bill
				wallet[i] = new Bill(billValue);

			} 
			else if (dataItem == 'Q')
				// create a quarter
				wallet[i] = new Quarter();
			else if (dataItem == 'D')
				// create a dime
				wallet[i] = new Dime();
			else if (dataItem == 'N')
				// create a nickel
				wallet[i] = new Nickel();
			else if (dataItem == 'P')
				// create a penny 
				wallet[i] = new Penny();
		}
		// print the wallet
		printWallet();
		// Sum the wallet and print out
		System.out.println("Summing wallet:");
		sumWallet(wallet);
	}

	/**
	 * Print the elements in <i>wallet</i>
	 */
	public static void printWallet() {
		for (int i = 0; i < wallet.length; i++) {
			System.out.println(wallet[i]);
		}
	}

	/**
	 * Sums the Money objects and prints to standard out.
	 * 
	 * @param wal
	 *            array of Money objects to be summed
	 */
	public static void sumWallet(Money[] wal) {
		int sumCents = 0;
		for (Money i : wal) {
			if (i instanceof Bill) {
				sumCents += (((Bill) i).getValue() * 100);
			} else if (i instanceof Coin) {
				sumCents += ((Coin) i).getValue();
			}
		}
		System.out.println("$" + (sumCents / 100) + "." + (sumCents % 100));
	}

}
