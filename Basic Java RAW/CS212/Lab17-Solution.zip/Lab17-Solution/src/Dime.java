
public class Dime extends Coin {

      public Dime () {
         super (10);
      }
}
