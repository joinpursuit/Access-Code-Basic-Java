
public class Quarter extends Coin {

      public Quarter () {
         super (25);
      }
}
