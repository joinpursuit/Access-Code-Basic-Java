
public class Penny extends Coin {

      public Penny () {
         super (1);
      }
}
