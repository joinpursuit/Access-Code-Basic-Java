
public class SomeIntegerNumber implements Comparable<SomeIntegerNumber>
{
	private int myNum;
	
	public SomeIntegerNumber(int num)
	{
		myNum=num;
	}
	@Override
	public int compareTo(SomeIntegerNumber o) 
	{
		// TODO Auto-generated method stub
		return myNum-o.myNum;
	}

		public static void main(String[] args) {
			SomeIntegerNumber num1 = new SomeIntegerNumber(5);
			SomeIntegerNumber num2 = new SomeIntegerNumber(6);
			System.out.println(num1.compareTo(num2));
		}
}
