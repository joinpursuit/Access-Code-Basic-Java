
public class Money implements Comparable<Money> {
	
	private int dollars, cents;
	
	/**
	 * Constructor makes a call to {@link #Money(int, int)} 
	 * with (0,0) as parameters
	 */
	public Money() {
		this(0,0);
	}
	
	/**
	 * Constructor which creates a Money object where the cents
	 * are normalized between 0 and 100.
	 * @param dollars the dollar value to be set
	 * @param cents the cents value to be normalized and set
	 */
	public Money(int dollars, int cents) {
		this.dollars = cents/100 + dollars;
		this.cents = cents%100;
	}
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// LAB 14
		Money m1 = new Money(), m2= new Money(6,5);
		System.out.println(m1.getCents());
		System.out.println(m2.getDollars());
		System.out.println(m2);
		System.out.println(m1.compareTo(m2));
		System.out.println(m1.equals(m2));
		
		// LAB 15
		m1 = new Money(4,87);
		m2 = new Money(5,243);
		
		m1.add(m2);
		
		System.out.println(m1.toString());
		
	}

	/**
	 * Adds <i>this</i> Money object to Money object <b>other</b> and stores the result back
	 * into <i>this</i>
	 * @param other the other Money object to be added to this
	 */
	public void add(Money other) {
		// get total cent value
		int centsTot = this.cents + other.cents;
		// add this dollars to other dollars and dollar from cents if any
		this.dollars += other.dollars + centsTot/100;
		// set the cents value
		this.cents = centsTot%100;
		
	}

	@Override
	public int compareTo(Money other) {
		// just view compareTo as a subtraction operation
		int dollarCalc = this.dollars - other.dollars;
		if(dollarCalc==0) {
			return this.cents - other.cents;
		}
		return dollarCalc;
	}
	
	/**
	 * Equal only when dollars and cents are equal.
	 */
	@Override
	public boolean equals(Object other) {
		// reflexive property
		if (this == other) return true;
		// if Object other is of type Money
		if(other!=null && this.getClass().equals(other.getClass())) {
			// cast to Money
			Money temp = (Money) other;
			// return true if equal false otherwise
			return this.compareTo(temp) == 0;
		}
		// return false when null or not of type Money
		return false;
	}
	
	/**
	 * Returns the string representation of the Money object in the format:
	 * $[dollars].[cents]
	 */
	@Override
	public String toString() {
		String c;
		if(cents<10) {
			c = "0" + cents;
		} else {
			c = "" + cents;
		}
		return "$ " + dollars + "." + c;
	}
	
	public int getCents() {
		return cents;
	}
	
	public int getDollars() {
		return dollars;
	}

}
