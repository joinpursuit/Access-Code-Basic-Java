public class departmentList {
	
	private String Department;
	private CourseList DepartmentCourses;
	public departmentList next;
	
	/**
	 * creates a department listnode with courselist inside it
	 * @param Department
	 * @param DepartmentCourses
	 */
	public departmentList(String Department, CourseList DepartmentCourses)
	{
		this.Department = Department;
		this.DepartmentCourses = DepartmentCourses;
	}
	
	/**
	 * @return all the courses in the particular department
	 */
	public CourseList getDepartmentCourses()
	{
		return DepartmentCourses;
	}
	
	/**
	 * @return the department name
	 */
	public String getDepartment()
	{
		return Department;
	}
	
	
}

