public class Project3 {

	
	public static Project3Gui Gui;
	
	/**
	 * CS211 Project 3.
	 * Haiqiang Zou, Xu Xiang, Lin Mei Ling
	 * @param args
	 */
	//reads in the file and starts the GUI
	public static void main(String[] args) 
	{		
		Gui = new Project3Gui("Our CunyFirst", 500, 300);
	}
}

