
public class CourseList {
	
	private Course dummy = new Course(null,null, null, null, null, null, null, null, null);
	private Course first = dummy;
	private Course last = dummy;
	private int length = 0;
	
	/**
	 * appends the course into the courseList 
	 * @param courses
	 */
	public void append(Course courses)
	{
		last.setNext(courses);
		last = courses;
		length++;
	}
	
	/**
	 * it searches the courseList for the courses.
	 * @param CourseNumber
	 * @return nulls if the course doesnt exist or return the position if the course exist
	 */
	public Course searchCourseNumber(String CourseNumber)
	{
		
		Course searchCourseNumber = first.next;
		
		//searches the courselist to c if the course exist. if it doesn't returns null
		while(searchCourseNumber != null){
		
			if(searchCourseNumber.getNumber().equalsIgnoreCase(CourseNumber))
			{
				return searchCourseNumber;
			}
			
			searchCourseNumber = searchCourseNumber.next;
		}
		
		return null;
	}
		
	/**
	 * overwrites the toString methods for courseList
	 */
	public String toString()
	{
		
		String CoursesInDepartment = "";
		
		Course c = first.next;
		
		//adds the course number into the string
		while(c != null)
		{
			CoursesInDepartment += "Course Number: "+c.getNumber() + "\n\n";
			c = c.next;
		}
		
		
		//returns course number string
		return CoursesInDepartment;
	}
	
	/**
	 * gets the length of the courselist
	 * @return
	 */
	public int getLength()
	{
		return length;
	}
}
