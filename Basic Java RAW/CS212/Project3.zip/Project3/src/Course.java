public class Course {
	
	private String courseID, date, department, courseNumber, credits, hours, schedulable, description, title;
	public Course next;
	
	/**
	 * A 9 argument constructor which gets all the course informations
	 * @param courseID
	 * @param date
	 * @param department
	 * @param courseNumber
	 * @param credits
	 * @param hours
	 * @param schedulable
	 * @param description
	 * @param title
	 */
	public Course(String courseID, String date, String department, String courseNumber, String credits, String hours, String schedulable, String description, String title)
	{
		this.courseID = courseID;
		this.date = date;
		this.department = department;
		this.courseNumber = courseNumber;
		this.credits = credits;
		this.hours = hours;
		this.schedulable = schedulable;
		this.description = description;
		this.title = title;
	}
	
	/**
	 * @return courseID
	 */
	public String getCourseID()
	{
		return courseID;
	}
	
	/**
	 * @return the date
	 */
	public String getDate()
	{
		return date;
	}
	
	/**
	 * @return department
	 */
	public String getDepartment()
	{
		return department;
	}
	
	/**
	 * @return courseNumber
	 */
	public String getNumber()
	{
		return courseNumber;
	}
	
	/**
	 * @return credit
	 */
	public String getCredits()
	{
		return credits;
	}
	
	/**
	 * @return hours
	 */
	public String getHours()
	{
		return hours;
	}
	
	/**
	 * @return schedulable
	 */
	public String getSchedulable()
	{
		return schedulable;
	}
	
	/**
	 * @return description
	 */
	public String getDescription()
	{
		return description;
	}
	
	/**
	 * @return title
	 */
	public String getTitle()
	{
		
		return title;
	}

	/**
	 * goes to the next course.
	 * @param c
	 */
	public void setNext(Course c)
	{
		next = c;
	}
	
	/**
	 * overwrites the toString methods
	 */
	public String toString()
	{
		return
		department+" "+courseNumber+". "+title+"\n"+hours+" hr., "+
		credits+" cr. \n"+description+"\n"+
		"Course ID: "+courseID+", Effective Date: "+date+", Schedulable = "+schedulable;
	}
}
