import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
public class FileMenuHandler implements ActionListener {

	TextArea myTextArea;
	JFrame jframe;
	
	/**
	 * Constructor to start the file menu handler for JFrame
	 * @param jf
	 */
	public FileMenuHandler (JFrame jf) 
	{
      jframe = jf;
    }
	
	/**
	 * Instructions on what action should be performed when the menu names are clicked.
	 */
	public void actionPerformed(ActionEvent event) 
	{
      String  menuName;
      menuName = event.getActionCommand();
      if (menuName.equals("Open"))
      {
    	  openFile( );   	  
      }
      
      //exits the program if user clicks quit
      else if (menuName.equals("Quit"))
        System.exit(0);
      
      //calls the method display all department method when all departments are clicked
      else if(menuName.equals("All Departments"))
      	displayAllDepartments();
      
      //calls the methods display department method when department is clicked
      else if(menuName.equals("Department"))
    	displayDepartment();
      
      //calls the displayCourse method when courses are clicked
      else if(menuName.equals("Courses"))
    	displayCourse();
      
      
	} //actionPerformed

	/**
	 * Let user choose which file to Open
	 */
    private void openFile( )
    {
       JFileChooser chooser;
       int          status;
       chooser = new JFileChooser( );
       status = chooser.showOpenDialog(null);
       if (status == JFileChooser.APPROVE_OPTION) 
       {
    	   readSource(chooser.getSelectedFile());
       }
       
       else 
          JOptionPane.showMessageDialog(null, "Open File dialog canceled");
    } //openFile
  
    
    /**
     * reads in the files from the opened file and created a linkedlist with it.
     * also creates a textArea and display a message saying the file has been loaded.
     * @param chosenFile
     */
    private void readSource(File chosenFile)
    {
       String chosenFileName = chosenFile.getName();
       Container myContentPane = jframe.getContentPane();
       
       //adds the text area when user opens the file and creates a linked listed
       myTextArea = new TextArea();
       myTextArea.setEditable(false);
       readFile a = new readFile(chosenFileName);
       myContentPane.add(myTextArea, BorderLayout.CENTER);
       myTextArea.setText(chosenFileName + " has been loaded " +"\n");
       jframe.setVisible(true);  
    }
    
    /**
     * displays all the department into the text area
     */
    private void displayAllDepartments()
    {
        myTextArea.setText(readFile.printDepartments() +"\n");
    }
    
    /**
     * Asks the user to enter a department 
     * and displays all the course number in that department
     */
    private void displayDepartment()
    {
    	//asks the user to input a department name
    	String input = JOptionPane.showInputDialog("Enter a department name: " );
    	
    	//if user enters in nothing the program exits.
    	if(input==null)
    		System.exit(0);
    	
    	//when the department that user enters is invalid it will keep telling the user to enter until a valid department is entered.
    	while((readFile.AllDepartments.searchDept(input))==null)
    	{
    		JOptionPane.showMessageDialog(null, "The department does not exist, Please enter a valid department");
    		input = JOptionPane.showInputDialog("Enter a department name: " );
    		if(input==null)
        		System.exit(0);
    	}
    	
    	//returns the name of all department in a string.
    	myTextArea.setText(input.toUpperCase() + " Department Courses \n\n" +((readFile.AllDepartments.searchDept(input)).getDepartmentCourses()).toString());
    }
    
    /**
     * Asks the user to enter the department and course number so it will display the course in detail
     */
    private void displayCourse()
    {
    	String department, courseNumber;
    	
    	//asks the user to input a department name and course number
    	String input = JOptionPane.showInputDialog("Enter a department name and course number in this format: CourseName Number" );
    	
    	//if user doesnt enter anything the program exits.
    	if(input==null)
    		System.exit(0);
    	
    	//splits the user input into two parts. first is the department name and second is the course number
    	String[] courseParts = input.split(" ");
    	department = courseParts[0];
    	courseNumber = courseParts[1];
    	
    	//if the department or course number user enter is invalid it will tell the user to input again
    	while((readFile.AllDepartments.searchDept(department).getDepartmentCourses().searchCourseNumber(courseNumber))==null)
    	{
    		JOptionPane.showMessageDialog(null, "The department/course does not exist, Please enter a valid department/course");
    		input = JOptionPane.showInputDialog("Enter a department name and course number in this format: CourseName Number" );
    		if(input==null)
        		System.exit(0);
    		courseParts = input.split(" ");
    		department = courseParts[0];
        	courseNumber = courseParts[1];
    	}
    	myTextArea.setText((readFile.AllDepartments.searchDept(department).getDepartmentCourses().searchCourseNumber(courseNumber)).toString());

    }
}