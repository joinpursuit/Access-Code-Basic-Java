
public class readFile {
	
	public static departmentLink AllDepartments = new departmentLink();
	private String courseID, date, department, courseNumber, credits, hours, schedulable, description, title;
	
	/**
	 * A constructor to read in all the lines in the text file and store them into the linkList
	 * @param Filename
	 */
	public readFile(String Filename) {
		TextFileInput in = new TextFileInput(Filename);
		String line = in.readLine();
		
		//reads in every line in the test file
		while (line != null) {
			String[] courseParts = line.split("\t");
			
			if(courseParts.length==9)
			{
			courseID = courseParts[0];
			date = courseParts[1];
			department = courseParts[2];
			courseNumber = courseParts[3];
			credits = courseParts[4];
			hours = courseParts[5];
			schedulable = courseParts[6];
			description = courseParts[7];
			title = courseParts[8];
			}
			
			//if the length of the line does not equals 9 after split. it reads in a new line and continue the loop
			if (courseParts.length != 9) {
				line=in.readLine();
				continue;
			} 
			
			//searches all department to see if the department exist. if it doesnt then it creates a new department list node
			else if (AllDepartments.searchDept(department) == null) 
			{
				AllDepartments.append(department, new CourseList());
				Course courses = new Course( courseID, date, department, courseNumber, credits, hours, schedulable, description, title);
				AllDepartments.AddCoursesToDepartment(department, courses);
			} 
			
			//searches all department to see if the department exist. then it adds the course to the department
			else
			{
				Course courses = new Course( courseID, date, department, courseNumber, credits, hours, schedulable, description, title);
				AllDepartments.AddCoursesToDepartment( department, courses);
				
			}
			line = in.readLine();	
		}
		
	}
		
	/**
	 * String method to print out all the departments in the link list
	 * @return all department
	 */
	public static String printDepartments()
		{
			return AllDepartments.printDepartment();
		}
	

}		
