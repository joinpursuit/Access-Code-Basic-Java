import java.util.Arrays;

public class departmentLink {
	
	private departmentList dummy = new departmentList(null, null);
	private departmentList first = dummy;
	private departmentList last = dummy;
	private int length = 0;
	
	/**
	 * it appends the department listnode with a course listnode inside it
	 * @param Department
	 * @param DepartmentList
	 */
	public void append(String Department, CourseList DepartmentList)
	{
		
		last.next = new departmentList(Department, DepartmentList);
		last = last.next;
		length++;
	}
	
	/**
	 * gets the length of the department LinkedList
	 * @return
	 */
	public int getLength()
	{
		return this.length;
	}
	
	/**
	 * it searches the department to see if the department exist.
	 * @param Department
	 * @return null when department doesn't exist or else return the position of the department.
	 */
	public departmentList searchDept(String Department)
	{
		
		departmentList searchDepartment = first.next;
		
		//searches the department to see if the department pass in exist. if it doesnt then it returns null.
		while(searchDepartment != null)
		{
			if(searchDepartment.getDepartment().equalsIgnoreCase(Department))
			{
				return searchDepartment;
			}
			searchDepartment = searchDepartment.next;
		}
		return null;
	}

	/**
	 * adds the course to the department if the departmentname matches with the department listnode
	 * @param Department
	 * @param Courses
	 */
	public void AddCoursesToDepartment(String Department, Course Courses){
		
		departmentList departments = first.next;
		
		//it adds the course to the right department
		while(departments != null){
		
			if(departments.getDepartment().equalsIgnoreCase(Department)){
			
				departments.getDepartmentCourses().append(Courses);
			}
			
			departments = departments.next;
		
		}
		
	}
	
	/**
	 * it takes all the department name from the department Linklist and sorts them into alphabetical order
	 * @return the department names in alphabetical order
	 */
	public String printDepartment()
	{
		//creates a 1d array and set it the size of the linklist length
		String[] sortDepartment = new String [length];
		String department = "";

		departmentList p = first.next;

		//stores the department names into the 1d array
		for(int i = 0; p !=null; p=p.next)
		{
			sortDepartment[i]=p.getDepartment();
			i++;
		}
		
		//sorts the department name into alphabetical order
		Arrays.sort(sortDepartment);
		
		//adds the department name into the string
		for(int i = 0; i < length; i++)
		{
			department+=sortDepartment[i]+"\n";
		}
		
		//returns string department
		return department;
	}
	
}
