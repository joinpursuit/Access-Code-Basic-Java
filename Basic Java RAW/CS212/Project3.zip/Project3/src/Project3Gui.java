import javax.swing.*;
import java.awt.*;
public class Project3Gui extends JFrame {
      
/**
 * A constructor for the GUI
 * @param title
 * @param height
 * @param width
 */
   public Project3Gui(String title, int height, int width) 
   {
	    setTitle(title);
	    setSize(height,width);
        setLocation(400,200);
	    createFileMenu();
	    setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
   } //SSNGUI

   /**
    * creates the file menu on the GUI 
    * with 2 JMenu and 5 menu items total
    */
   private void createFileMenu( ) 
   {
	   
      JMenuItem item;
      JMenuBar menuBar  = new JMenuBar();
      JMenu fileMenu = new JMenu("File");
      JMenu fileMenu2 = new JMenu("Find");
      FileMenuHandler fmh  = new FileMenuHandler(this);

      //adds open to filemenu
      item = new JMenuItem("Open");    //Open...
      item.addActionListener( fmh );
      fileMenu.add( item );

      fileMenu.addSeparator();           //add a horizontal separator line
  
      //adds quit to file menu
      item = new JMenuItem("Quit");       //Quit
      item.addActionListener( fmh );
      fileMenu.add( item );
      
      //adds all department to second file menu
      item = new JMenuItem("All Departments");
      item.addActionListener( fmh );
      fileMenu2.add(item);
      
      fileMenu2.addSeparator();		//add a horizontal separator line
      
      //adds department to second file menu
      item = new JMenuItem("Department");
      item.addActionListener( fmh );
      fileMenu2.add(item);
      
      fileMenu2.addSeparator();
      
      //adds courses to second file menu
      item = new JMenuItem("Courses");
      item.addActionListener( fmh );
      fileMenu2.add(item);
      
      setJMenuBar(menuBar);
      menuBar.add(fileMenu);
      menuBar.add(fileMenu2);
    
   } //createMenu

} //SSNGUI
